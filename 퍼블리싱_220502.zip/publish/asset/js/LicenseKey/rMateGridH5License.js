// -----------------------------------------------------------------------------
// rMate Grid H5 License Key 
//
// Product Name : rMate Grid for HTML5 v5.0
// License Type : Enterprise license
// Product No : CB5B-4F25-A7EE-8A4Y
// Authenticated server Info : undefined
// Expiration date : 2022/06/30
//
var rMateGridH5License = "29f85d178fad706e25bedd2659f4b343a99788e89f842719de2734f825513f8b:6600320b3548443a4f4220504c2056593a3432412e38302d2045504556373a41472d35352d3245464e342d2d35422e3530422d43453a564c41204c302033452f4c363a30742f203243323a303232303a32453220302a333a324839";
// -----------------------------------------------------------------------------
